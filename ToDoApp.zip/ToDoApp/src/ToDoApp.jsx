import "./ToDoApp.css"
import TextField from "./TextField"
import Button from "./Button"
import { useState } from "react"



function ToDoApp() {

    // To handle task input
    let [task,settask]=useState("")

    let [tasklist,settasklist]=useState([])

    // To handle messages
    let [message, setMessage] = useState("");

    let [messageType, setMessageType] = useState("");



    let updateTask=({target:{value}})=>
    {
        settask(value)
    }

    let addTask = () => { 

    // Empty input message
    if (task.trim() === "") {

        setMessage("Please add task");

        setMessageType("error");

        setTimeout(() => {

            setMessage("");

            setMessageType("");

        }, 1000);

    }

    else{
    settasklist([...tasklist, task]);
    settask("");

    // Success message
    setMessage("Task added successfully");

    setMessageType("success");

    setTimeout(() => {

        setMessage("");

        setMessageType("");

    }, 1000);}
};


    let deleteTask=(id)=>
    {
        let remainingTasks=tasklist.filter((taskitem,index)=>
        {
            return id!==index
        })
        settasklist(remainingTasks)
    }

    let clearTaskList=()=>
    {
        settasklist([])
    }


  return (
    <div className='todo-app'>


        {/* Message display area */}
        {message && (

            <div className={`message ${messageType}`}>

                {message}
                
            </div>
        )}



      <div className="add-item">

        <TextField type="text" placeholder="Task" onchange={updateTask} value={task} />
        <Button text="Add" classname="btn-success" onclick={addTask} />

      </div>
      <hr />

      <div className="items">

        {tasklist.map((taskitem,index)=>
        {
            return <div key={index} className="item">
                        <p>{taskitem}</p>
                        <Button text="delete" classname="btn-danger" onclick={()=>
                            {
                                deleteTask(index)
                            }
                        } />
                    </div>
        })}
 
      </div>
      
      <div className="clear">
        <Button text="clear All Task" onclick={clearTaskList} classname="btn-primary" />
      </div>
    </div>
  )
}


export default ToDoApp;

